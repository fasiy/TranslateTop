import Footer from './footer';
import FooterText from './footer_text';
import FooterLinks from './footer_links';
import FooterLink from './footer_link';

export {
    Footer,
    FooterText,
    FooterLinks,
    FooterLink
};