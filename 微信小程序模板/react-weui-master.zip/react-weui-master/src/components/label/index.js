/**
 * Created by yjcxy12 on 16/1/22.
 */



import Label from './label';

export default Label;
