import Gallery from './gallery';
import GalleryDelete from './gallery_delete';

export {
    GalleryDelete,
    Gallery
};