import Msg from './msg';

export default Msg;