/**
 * Created by jf on 15/12/11.
 */



import Article from './article';

export default Article;