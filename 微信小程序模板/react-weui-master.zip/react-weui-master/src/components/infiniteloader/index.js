import InfiniteLoader from './infiniteloader';

export default InfiniteLoader;