import PullToRefresh from './ptr';

export default PullToRefresh;