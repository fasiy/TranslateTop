import Swiper from './swiper';

export default Swiper;