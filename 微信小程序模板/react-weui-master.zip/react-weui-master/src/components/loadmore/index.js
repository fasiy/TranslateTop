import LoadMore from './loadmore';

export default LoadMore;