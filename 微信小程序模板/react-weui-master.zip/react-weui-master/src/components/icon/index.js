/**
 * Created by jf on 15/11/3.
 */

import Icon from './icon';

export default Icon;