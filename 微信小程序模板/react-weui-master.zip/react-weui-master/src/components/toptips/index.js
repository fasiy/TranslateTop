import Toptips from './toptips';

export default Toptips;