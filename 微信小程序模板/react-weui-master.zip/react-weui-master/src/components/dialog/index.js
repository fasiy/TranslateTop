
import Dialog from './dialog';

export default Dialog;