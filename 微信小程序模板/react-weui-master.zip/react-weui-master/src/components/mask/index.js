/**
 * Created by jf on 15/10/27.
 */



import Mask from './mask';

export default Mask;