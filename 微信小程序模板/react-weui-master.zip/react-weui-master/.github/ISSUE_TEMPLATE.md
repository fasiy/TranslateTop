**Do you want to request a *feature* or report a *bug* (建议还是bug) ?**

**What is the current behavior? (现有状况)**

**What is the expected behavior? （应有状况）**

**Which versions of React-weui, weui, and which OS and device are affected by this issue? (React-weui版本 weui版本 机型和系统)**
